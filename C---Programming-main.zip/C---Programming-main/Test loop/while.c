#include <stdio.h>
int main()
{
  printf("\nUsing whie loop;\n");
  int j =1;
  while(j<=5)
  
}
  printf("%d\n",j);
  j++;
  
  return 0;
  }
