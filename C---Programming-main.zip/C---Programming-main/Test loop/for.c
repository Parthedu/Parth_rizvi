#include <stdio.h>
int main()
{
  printf("Using for loop:\n");
  for(int i=1;i<=5;i++)

{
  printf("%d\n",i);
}
    
return 0;
}
