#include <stdio.h>
int main()
{
  printf("\n Using do-whie loop;\n");
  int k =1;
  do

{
  printf("%d\n",k);
  k++;
  } while(k<=5);

return 0;
  }
